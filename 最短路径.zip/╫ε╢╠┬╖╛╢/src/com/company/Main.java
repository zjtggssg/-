package com.company;
import java.io.*;
import java.util.*;

public class Main {
    public static Map<Integer, Station> map;
    public static Map<String, Integer> numMap;
    public static Set<String> set;
    public static Map<String, Line> lines;
    public static Set<List<String>> readSet;
    public static int len;
    public static int count;
    public static int[][] table;
    public static int INF = Integer.MAX_VALUE;
    public static int[][] path;
    public static int[][] dist;
    public static int start;
    public static int stop;
    //顶点i 到 j的最短路径长度，初值是i到j的边的权重

    public static List<Integer> result = new ArrayList<Integer>();
    public static void main(String[] args) throws Exception {
        if (args[0].equals("-a")){
            String readfile = args[3];
            init(readfile);
          //init("station.txt");
            statisticsStation();
            getHashMap();
            buildMap();
          readline(readfile);
          //  readline("station.txt");
            check(args[1]);

            writeLine(args[1],args[5]);
        }
        else {
            String readfile = args[4];
            init(readfile);
            //init("station.txt");
            statisticsStation();
            getHashMap();
            buildMap();
            readline(readfile);
            totable();
            DIJKSTRA(args[1],args[2]);
            writeLine2(args[6]);

        }
    }
 public static void DIJKSTRA(String begin ,String end) {
     int n=table.length;
      start =numMap.get(begin);
      stop =numMap.get(end);
     findCheapestPath(start, stop, table);
     List<Integer> list = result;
     System.out.println(begin + " to " + end + ",the cheapest path is:");
//     System.out.println(list.toString());
     for(int i:list){
         System.out.println(map.get(i).getStationName());
     }
     System.out.println(dist[start][stop]);
           
     }
    public static void findCheapestPath(int begin, int end, int[][] table) {
        floyd(table);
        result.add(begin);
        findPath(begin, end);
        result.add(end);
    }

    public  static void findPath(int i, int j) {
        int k = path[i][j];
        if (k == -1) {
            return;
        }
        findPath(i, k);   //递归
        result.add(k);
        findPath(k, j);
    }

    public static void floyd(int[][] table) {
        int size = len;
        path = new int[size][size];
        dist = new int[size][size];
        //initialize dist and path
        System.out.println(size);
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                path[i][j] = -1;
                dist[i][j] = table[i][j];
            }
        }
        for (int k = 0; k < size; k++) {
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    if (dist[i][k] != INF &&
                            dist[k][j] != INF &&
                            dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                        path[i][j] = k;
                    }
                }
            }
        }

    }

    public static List<String> check(String linename){
        Line line=lines.get(linename);
        List<Station>stations=line.getStations();
        List<String>strings=new ArrayList<String>();
        for(Station station:stations){
            strings.add(station.getStationName());
        }
     return strings;
    }

    public static Set<List<String>> readline(String filename) throws Exception {
        FileInputStream inputStream = new FileInputStream(filename);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        Set<List<String>>set=new HashSet<List<String>>();
        String str = null;
        while ((str = bufferedReader.readLine()) != null) {

            String[] lineInformations = str.split(" ");
            List<String>stations=new ArrayList<String>();
            for (String s : lineInformations) {
                stations.add(s);

            }
            set.add(stations);
        }
        //close
        inputStream.close();
        bufferedReader.close();
        return set;
    }
    private static void init(String filename) throws Exception {
        map = new HashMap<Integer, Station>();
        numMap = new HashMap<String, Integer>();
        set = new HashSet<String>();
        lines = new HashMap<String, Line>();
        readSet=readline(filename);

    }

    private static void statisticsStation() {
        for (List<String> lineList : readSet) {
            for (int i = 1; i < lineList.size(); i++) {
                set.add(lineList.get(i));
            }
        }
    }
    private static void getHashMap() {
        count = 0;
        for (String s : set) {
            Station station = new Station(s);
            map.put(count, station);
            numMap.put(s, count);
            count++;
        }
    }
    private static void buildMap() {
        for (List<String> lineList : readSet) {
            Line line = new Line(lineList.get(0));
            for (int i = 1; i < lineList.size(); i++) {
                Station station = map.get(numMap.get(lineList.get(i)));
                station.addLine(line);
                if (i != 1) {
                    Station laStation = map.get(numMap.get(lineList.get(i - 1)));
                    station.addConn(laStation);
                    laStation.addConn(station);
                }
                line.addStation(station);
            }
            lines.put(lineList.get(0), line);
        }
    }
    public static void totable(){
      len = map.size();
      table =new int[len][len];
      for(int i=0;i<len;i++){
          for(int  j=0;j<len;j++){
              table[i][j]=INF;
          }
      }
     for(int i=0;i<len;i++){
         Station station=map.get(i);
         for(Station s:station.getConn()){
             int j=numMap.get(s.getStationName());
             table[i][j]=1;
             table[j][i]=1;
         }
     }
    }
    public static void writeLine(String linename,String fileName) throws Exception {

        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName)));

        out.write(linename);
        out.newLine();
        for(Station s:lines.get(linename).getStations()){
            out.write(s.getStationName());
            out.newLine();
        }
        out.flush();
        out.close();

    }
    public static void writeLine2(String fileName) throws Exception {

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName)));

            out.write(map.get(start).getStationName() + " to " + map.get(stop).getStationName() + ",the cheapest path is:");
            out.newLine();
            out.write(dist[start][stop]+"");
            out.newLine();
            for(Integer r: result){
                out.write(map.get(r).getStationName());
                out.newLine();
            }

            out.flush();
            out.close();

        }


}
